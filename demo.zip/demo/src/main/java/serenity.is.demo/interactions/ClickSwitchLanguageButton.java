package serenity.is.demo.interactions;

public class ClickSwitchLanguageButton {
}

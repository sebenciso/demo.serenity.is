package serenity.is.demo.interactions;

public class LoginPage {
}

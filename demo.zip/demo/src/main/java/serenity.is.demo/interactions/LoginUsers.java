package serenity.is.demo.interactions;

public interface LoginUsers {
    <T extends Actor> void performAs(T actor);
}

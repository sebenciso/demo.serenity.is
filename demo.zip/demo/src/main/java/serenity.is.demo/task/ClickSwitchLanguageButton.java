package serenity.is.demo.task;
// Aquí está la clase ClickSwitchLanguageButton que representa la acción de hacer clic en el botón de cambio de idioma.

import javafx.concurrent.Task;

public class ClickSwitchLanguageButton<DashboardPage> extends serenity.is.demo.interactions.ClickSwitchLanguageButton implements Task {
    private static DashboardPage Dashboard;
    private DashboardPage dashboardPage;

    public ClickSwitchLanguageButton(DashboardPage dashboardPage) {
        this.dashboardPage = dashboardPage;
    }

    public static ClickSwitchLanguageButton on() {
        return on(Dashboard);
    }

    public static ClickSwitchLanguageButton on(DashboardPage dashboardPage) {
        return instrumented(ClickSwitchLanguageButton.class, dashboardPage);
    }

    private static <DashboardPage> ClickSwitchLanguageButton instrumented(Class<ClickSwitchLanguageButton> clickSwitchLanguageButtonClass, DashboardPage dashboardPage) {
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        dashboardPage.clickSwitchLanguageButton();
    }

    protected Object call() throws Exception {
        return null;
    }
}

/*
En esta clase, se recibe una instancia de la página DashboardPage y se usa el método clickSwitchLanguageButton()
para hacer clic en el botón de cambio de idioma.
La clase también incluye el método estático on()
para facilitar la creación de la tarea en otras partes del código.
*/
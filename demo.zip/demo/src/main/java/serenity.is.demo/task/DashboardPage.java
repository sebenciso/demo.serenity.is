import com.sun.tools.javac.util.Assert;
import serenity.is.demo.exeptions.WebElement;
import serenity.is.demo.interactions.ClickSwitchLanguageButton;
import serenity.is.demo.utildhc.Performable;

public class DashboardPage implements Performable {

    private final Actor actor;
    private final WebDriver driver;

    private final WebElement switchLanguageButton;
    private final WebElement languageList;

    public DashboardPage(Actor actor) {
        this.actor = actor;
        this.driver = Serenity.getWebdriverManager().getCurrentDriver();

        switchLanguageButton = driver.findElement(By.id("switch-language-button"));
        languageList = driver.findElement(By.id("language-list"));
    }

    public static Performable verifyDashboardIsDisplayed() {
        return new DashboardPageDisplayed();
    }

    public static ClickSwitchLanguageButton clickSwitchLanguageButton() {
        return new ClickSwitchLanguageButton(new DashboardPage(actor));
    }

    public void clickSpanishButton() {
        WebElement spanishButton = driver.findElement(By.id("spanish-button"));
        spanishButton.click();
    }

    public void verifyDashboardIsDisplayedInSpanish() {
        WebElement dashboardTitle = driver.findElement(By.id("dashboard-title"));
        String dashboardTitleText = dashboardTitle.getText();
        Assert.assertEquals("El Panel de Control", dashboardTitleText);
    }

    public void verifyLanguageListIsDisplayed() {
        Assert.assertTrue(languageList.isDisplayed());
    }

    private static class DashboardPageDisplayed implements Performable {
        @Override
        public <T extends Actor> void performAs(T actor) {
            WebDriver driver = Serenity.getWebdriverManager().getCurrentDriver();
            WebElement dashboardTitle = driver.findElement(By.id("dashboard-title"));
            Assert.assertTrue(dashboardTitle.isDisplayed());
        }
    }
}

/*
La clase DashboardPage implementa la interfaz Performable para permitir que las acciones Screenplay se realicen en ella.
El constructor de la clase toma un Actor como parámetro para poder interactuar con la página.

La clase incluye métodos estáticos para realizar acciones en la página, como verifyDashboardIsDisplayed(), clickSwitchLanguageButton(),
 y métodos no estáticos como clickSpanishButton(), verifyDashboardIsDisplayedInSpanish() y verifyLanguageListIsDisplayed().

También hay una clase interna privada DashboardPageDisplayed que se utiliza para verificar que el Dashboard se muestra correctamente.
 Esta clase también implementa la interfaz Performable.

La clase ClickSwitchLanguageButton también se usa en clickSwitchLanguageButton()
para realizar la acción de hacer clic en el botón de cambio de idioma.

En resumen, esta clase DashboardPage implementa el patrón de diseño Screenplay y los principios SOLID para facilitar
la prueba de la página del Dashboard.


 */



package serenity.is.demo.utildhc;

public interface Performable {
}

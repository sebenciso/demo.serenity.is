package serenity.is.demo.utildhc;

public class WebDriver {

    public WebDriver() {
        driver = WebDriverFactory.createChromeDriver();
    }

    public static WebDriver createChromeDriver() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\sarha\\IdeaProjects\\demo\\src\\main\\java\\serenity.is.demo\\utildhc\\chromedriver");
        return new ChromeDriver();
    }

    WebDriver driver;

    public void findElement(String id) {

    }

    public WebDriver(String s) {
    }

    public class WebDriverImpl extends WebDriver { }

    private static class ChromeDriver extends WebDriver {
    }
}

